# -*- coding: utf-8 -*-
"""
Created on Mon Apr 27 13:02:46 2020

@author: eshah
"""

#right start pattern
"""
def pattern(n):
    for i in range(0,n):
        for j in range(0,i+1):
            print("*",end=" ")
        print("\r")
    for i in range(n,-1,-1):
        for j in range(0,i+1):
            print("*",end=" ")
        print("\r")
pattern(10)
"""
def pattern(n):
    x=1
    for i in range(0,n):
        for j in range(0,i+1):
            print(x,end=" ")
            x+=1
        print("\r")
    for i in range(n,-1,-1):
        for j in range(0,i+1):
            print(x,end=" ")
            x+=1
        print("\r")
pattern(10)