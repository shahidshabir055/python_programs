# -*- coding: utf-8 -*-
"""
Created on Sat Apr 25 17:11:25 2020

@author: eshah
"""

def rearrange(A):
    for i in range(len(A)):
        A[i:i+2]=sorted(A[i:i+2],reverse=i%2)
    return A
a=[1,2,3,4,5,6]
print(rearrange(a))