# -*- coding: utf-8 -*-
"""
Created on Sun Mar  8 14:56:49 2020

@author: eshah
"""
def iswellformed (s) :
    left_chars, lookup = [], {'(': ')' }
    for c in s:
        if c in lookup:
            left_chars. append(c)
        elif not left_chars or lookup[left_chars.pop()]!=c:
            print("no")
    print("yes")
s='(()))'
iswellformed(s)