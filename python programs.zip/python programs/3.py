# -*- coding: utf-8 -*-
"""
Created on Sat Feb 15 16:32:47 2020

@author: eshah
"""

n=int(input("enter the n:"))
output=int(input("enter the expected output:"))
result=n*(n/2)+(n/2)
if(output==result):
    print(1)
else:
    print(0)