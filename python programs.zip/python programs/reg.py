# -*- coding: utf-8 -*-
"""
Created on Sat Mar  7 12:40:58 2020

@author: eshah
"""

import re
sentence="i am hacker"
regex=re.compile('(?P<noun>\w+)' '(?P<verb>\w+)(?P<adjective>\w+)')
matched=re.search(regex,sentence)
print(matched.group())