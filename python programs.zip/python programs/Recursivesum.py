#calculate sum of first n numbers using recursion
def recursive_sum(n):
    if n == 0:
        return 0
    #else:
    #   return recursive_sum(n-1)+n
    return recursive_sum(n-1)+n
def main():
    x = int(input("enter the value of x: "))
    s = recursive_sum(x)
    print("the sum of first n numbers is", s)
if __name__== "__main__":
    main()
