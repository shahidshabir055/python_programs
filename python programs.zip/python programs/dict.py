# -*- coding: utf-8 -*-
"""
Created on Tue Dec  3 18:58:23 2019

@author: eshah
"""
lt=["shabir"]
a=input("enter the key")
lt.append(a)
dict={"shahid":"ifrah","shabir":"qadri","BC":"mC"}
for i in lt:
    print(dict[i])

    