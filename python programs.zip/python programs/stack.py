# -*- coding: utf-8 -*-
"""
Created on Fri Mar  6 16:00:33 2020

@author: eshah
"""
import collections
class stack:
    ElementWithCachedMax=collections.namedtuple("ElementWithCahedMax",('element','max'))
    def __init__(self):
        self._Element_With_Cached_Max=[]
    def isEmpty(self):
        return len(self._Element_With_Cached_Max)==0
    def max(self):
        if self.isEmpty():
            raise IndexError('max(): empty stack')
        return self._Element_With_Cached_Max[-1].max
    def pop(self):
        if self.isEmpty():
            raise IndexError('pop(): empty stack')
        return self._Element_With_Cached_Max.pop().element
    def push(self,x):
        self._Element_With_Cached_Max.append(self.ElementWithCachedMax(x,x if self.isEmpty() else max(x,self.max())))
        
s=stack()
print(s.isEmpty())
s.push(2)
print(s.pop())
s.push(5)
print(s.pop())
#print(s.pop())