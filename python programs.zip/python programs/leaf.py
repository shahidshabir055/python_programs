# -*- coding: utf-8 -*-
"""
Created on Wed Nov 27 09:53:26 2019

@author: eshah
"""
"""
leap=2000
l=[]
while(len(l)<15):
	if((leap%4 == 0 and leap%100!=0) or (leap%400==0)):
		l.append(leap)
		leap=leap+1
print(l)
"""
"""
class mobile:
    def __init__(self,name,no):
        print("inside constructor")
        self.name="name"
        self.number="no"
mobile.name="readmi"
mobile.no="1234567"
mob1=mobile('nokia',1234)
mob2=mobile('abcd',3466)
mob2.name="samsung"
print(id(mobile))
print("name:",mobile.name)
print("number:",mobile.no)
print(id(mob1))
print(id(mob2))
print(mob2.name)
"""

#62 6 (9)

def encode(message):
    encoded=""
    count=1
    for i in range(len(message)):
        if(message[i]==message[i+1]):
            count=count(str(message[i]))
            encoded=encoded+str(count)+message[i]
            i=i+1
            return encoded
msg=encode("aaaabbccccac")
print(msg)
        