# -*- coding: utf-8 -*-
"""
Created on Sat Feb 15 16:38:11 2020

@author: eshah
"""
i=int(input("no. of elements"))
a=[]
for k in range(0,i):
    s=int(input())
    a.append(s)
for l in range(0,s):
    n=a[i+1]-a[i]+4
    a.append(n)
print(n)
    
    
    