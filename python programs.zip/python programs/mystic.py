# -*- coding: utf-8 -*-
"""
Created on Sat Feb 15 16:27:52 2020

@author: eshah
"""

r=int(input("roll no:"))
g=int(input("roll no:"))
ad= (r-g+1)*(-1)
print(ad)
