# -*- coding: utf-8 -*-
"""
Created on Sat Apr 25 16:50:29 2020

@author: eshah
"""
"""
def isDuplicate(A):
    i=1
    for x in range(1,len(A)):
        if A[i-1]!=A[x]:
            A[i]=A[x]
            i=i+1
    return A[:i]
A=[2,3,5,5,7,11,11,11,13]
print(isDuplicate(A))
"""
"""
def removeDuplicate(A):
    x=1
    for i in range(1,len(A)):
        if A[x-1]!=A[i]:
            A[x]=A[i]
            x=x+1
    return A[:x]
A=[2,3,5,5,7,11,11,11,13]
print(removeDuplicate(A))
"""
def remove_duplicate(A):
    x=1
    for i in range(1,len(A)):
        if A[x-1]!=A[i]:
            A[x]=A[i]
            x+=1
    return A[:x]
A=[2,3,5,5,7,11,11,11,13]
print(remove_duplicate(A))