# -*- coding: utf-8 -*-
"""
Created on Mon Apr 27 13:09:36 2020

@author: eshah
"""

#left start pyramid
"""
def pattern(n):
    k=2*n-2
    for i in range(0,n-1):
        for j in range(0,k):
            print(end=" ")
        k=k-2
        for j in range(0,i+1):
            print("*",end=" ")
        print("\r")
    k=-1
    for i in range(n-1,-1,-1):
        for j in range(k,-1,-1):
            print(end=" ")
        k=k+2
        for i in range(0,i+1):
            print("*",end=" ")
        print("\r")
pattern(10)
"""
def pattern(n):
    k=2*n-2
    for i in range(0,n-1):
        for j in range(0,k):
            print(end=" ")
        k=k-2
        for i in range(0,i+1):
            print("*",end=" ")
        print("\r")
    k=-1
    for i in range(n-1,-1,-1):
        for j in range(k,-1,-1):
            print(end=" ")
        k=k+2
        for i in range(0,i+1):
            print("*",end=" ")
        print("\r")
pattern(10)