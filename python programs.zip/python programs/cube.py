# -*- coding: utf-8 -*-
"""
Created on Sat Feb 15 16:18:18 2020

@author: eshah
"""
a=[1,2,3,4,5,6]
for i in range(0,6):
    print("the opposite faces are", a[i],7-a[i])
    