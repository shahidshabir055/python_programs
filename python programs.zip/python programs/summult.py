# -*- coding: utf-8 -*-
"""
Created on Sun Mar  8 11:51:33 2020

@author: eshah
"""

def isPossible(p,s,k):
    l=[]
    for i in range(1,p):
       if p % i == 0:
           l.append(i)
    return l
    while(k)
    for i in range(0,len(l)):
        
p=48
s=11
k=3       
print(isPossible(p,s,k))