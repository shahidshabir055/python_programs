# -*- coding: utf-8 -*-
"""
Created on Thu Mar  5 23:07:54 2020

@author: eshah
"""

def findpath(a):
    curPos=0
    lastPos=len(a)-1
    i=0
    while i <= curPos and curPos< lastPos:
        curPos=max(curPos,a[i]+i)
        i+=1
    return curPos>=lastPos
    
a=[2,4,1,1,0,2,3]
print(findpath(a))