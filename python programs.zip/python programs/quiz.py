# -*- coding: utf-8 -*-
"""
Created on Fri Mar 20 20:31:46 2020

@author: eshah
"""

def foo(x):
    def too(y):
        return x*y
    return too
 print(foo(3)(5))