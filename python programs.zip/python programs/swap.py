# -*- coding: utf-8 -*-
"""
Created on Fri Feb 21 16:34:33 2020

@author: eshah
"""
a=5
b=10
a=a+b
b=a-b
a=a-b
print(b)
print(a)

