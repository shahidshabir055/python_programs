# -*- coding: utf-8 -*-
"""
Created on Fri Mar  6 16:27:48 2020

@author: eshah
"""

def allper(string,i=0):
    if i==len(string):
        print("".join(string))
    for j in range(i,len(string)):
        s=[k for k in string]
        s[i],s[j]=s[j],s[i]
        allper(s,i+1)
string="hello"
print(allper(string))