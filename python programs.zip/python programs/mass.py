# -*- coding: utf-8 -*-
"""
Created on Sat Mar  7 11:06:28 2020

@author: eshah
"""

n=int(input())
k=int(input())
m=[1][2]
print(m)
#for i in range(0,n):
 #   x,y=int(input())
    
