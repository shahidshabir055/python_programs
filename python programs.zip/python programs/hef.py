# -*- coding: utf-8 -*-
"""
Created on Wed Mar 11 22:02:14 2020

@author: eshah
"""
d=20
def f(a,b):
    c=a+b
    print(d)
a=10
b=20
f(a,b)
print(c)