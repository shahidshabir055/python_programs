# -*- coding: utf-8 -*-
"""
Created on Thu Mar 12 15:29:52 2020

@author: eshah
"""

def findMul(arr,n):
    for 