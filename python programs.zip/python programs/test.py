# -*- coding: utf-8 -*-
"""
Created on Thu Nov 28 11:09:21 2019

@author: eshah
"""
def boarding(seat_number):
    if(seat_number>=1 and seat_number<=25):
        batch_no=1
    elif(seat_number>=26 or  seat_number<=100):
        batch_no=2
    elif(seat_number>=101 and seat_number<=200):
        batch_no=3
    else:
        batch_no=-1
    return batch_no
import pytest
#from <packagename>.solution import function_name

def test_boarding_1():
    result=boarding(3)
    assert result==1

def test_boarding_2():
    result=boarding(24)
    assert result==1