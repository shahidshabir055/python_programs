runfile('C:/Users/eshah/.spyder-py3/leaf2.py', wdir='C:/Users/eshah/.spyder-py3')

## ---(Thu Nov 28 18:16:39 2019)---
runfile('C:/Users/eshah/.spyder-py3/max.py', wdir='C:/Users/eshah/.spyder-py3')
2/31
2/3
int(2/3)
runfile('C:/Users/eshah/.spyder-py3/max.py', wdir='C:/Users/eshah/.spyder-py3')

## ---(Tue Dec  3 10:38:50 2019)---
numpy --version
runfile('C:/Users/eshah/.spyder-py3/max.py', wdir='C:/Users/eshah/.spyder-py3')
import numpy
numpy.version.version

## ---(Tue Dec  3 18:58:10 2019)---
runfile('C:/Users/eshah/.spyder-py3/dict.py', wdir='C:/Users/eshah/.spyder-py3')

## ---(Wed Dec  4 13:02:22 2019)---
runfile('C:/Users/eshah/.spyder-py3/dict.py', wdir='C:/Users/eshah/.spyder-py3')
runfile('C:/Users/eshah/.spyder-py3/dictionary.py', wdir='C:/Users/eshah/.spyder-py3')
runfile('C:/Users/eshah/.spyder-py3/numpy.py', wdir='C:/Users/eshah/.spyder-py3')

## ---(Wed Dec  4 19:09:56 2019)---
runfile('C:/Users/eshah/.spyder-py3/hr1.py', wdir='C:/Users/eshah/.spyder-py3')

## ---(Thu Dec  5 12:51:59 2019)---
runfile('C:/Users/eshah/.spyder-py3/hr1.py', wdir='C:/Users/eshah/.spyder-py3')

## ---(Thu Dec  5 18:52:52 2019)---
runfile('C:/Users/eshah/.spyder-py3/hr1.py', wdir='C:/Users/eshah/.spyder-py3')

## ---(Fri Dec  6 08:40:46 2019)---
runfile('C:/Users/eshah/.spyder-py3/tempConvert.py', wdir='C:/Users/eshah/.spyder-py3')
runfile('C:/Users/eshah/.spyder-py3/encoding.py', wdir='C:/Users/eshah/.spyder-py3')
runfile('C:/Users/eshah/.spyder-py3/leftroatation.py', wdir='C:/Users/eshah/.spyder-py3')
runfile('C:/Users/eshah/.spyder-py3/max.py', wdir='C:/Users/eshah/.spyder-py3')
runfile('C:/Users/eshah/.spyder-py3/dict.py', wdir='C:/Users/eshah/.spyder-py3')
runfile('C:/Users/eshah/.spyder-py3/dictionary.py', wdir='C:/Users/eshah/.spyder-py3')
runfile('C:/Users/eshah/.spyder-py3/numpy.py', wdir='C:/Users/eshah/.spyder-py3')
runfile('C:/Users/eshah/.spyder-py3/hr1.py', wdir='C:/Users/eshah/.spyder-py3')
runfile('C:/Users/eshah/.spyder-py3/tempConvert.py', wdir='C:/Users/eshah/.spyder-py3')
runfile('C:/Users/eshah/.spyder-py3/encoding.py', wdir='C:/Users/eshah/.spyder-py3')
runfile('C:/Users/eshah/.spyder-py3/leftroatation.py', wdir='C:/Users/eshah/.spyder-py3')
runfile('C:/Users/eshah/.spyder-py3/minumu.py', wdir='C:/Users/eshah/.spyder-py3')
runfile('C:/Users/eshah/.spyder-py3/bubblesort.py', wdir='C:/Users/eshah/.spyder-py3')
runfile('C:/Users/eshah/.spyder-py3/vubble.py', wdir='C:/Users/eshah/.spyder-py3')
runfile('C:/Users/eshah/.spyder-py3/bubblesort.py', wdir='C:/Users/eshah/.spyder-py3')
runfile('C:/Users/eshah/.spyder-py3/vubble.py', wdir='C:/Users/eshah/.spyder-py3')
runfile('C:/Users/eshah/.spyder-py3/bubblesort.py', wdir='C:/Users/eshah/.spyder-py3')
runfile('C:/Users/eshah/.spyder-py3/vubble.py', wdir='C:/Users/eshah/.spyder-py3')

## ---(Sat Dec  7 09:12:45 2019)---
runfile('C:/Users/eshah/.spyder-py3/encoding.py', wdir='C:/Users/eshah/.spyder-py3')
runfile('C:/Users/eshah/.spyder-py3/leftroatation.py', wdir='C:/Users/eshah/.spyder-py3')
runfile('C:/Users/eshah/.spyder-py3/minumu.py', wdir='C:/Users/eshah/.spyder-py3')
runfile('C:/Users/eshah/.spyder-py3/bubblesort.py', wdir='C:/Users/eshah/.spyder-py3')
runfile('C:/Users/eshah/.spyder-py3/vubble.py', wdir='C:/Users/eshah/.spyder-py3')
runfile('C:/Users/eshah/.spyder-py3/bubblesort.py', wdir='C:/Users/eshah/.spyder-py3')
runfile('C:/Users/eshah/.spyder-py3/vubble.py', wdir='C:/Users/eshah/.spyder-py3')
runfile('C:/Users/eshah/.spyder-py3/bubblesort.py', wdir='C:/Users/eshah/.spyder-py3')
runfile('C:/Users/eshah/.spyder-py3/encoding.py', wdir='C:/Users/eshah/.spyder-py3')
runfile('C:/Users/eshah/.spyder-py3/minumu.py', wdir='C:/Users/eshah/.spyder-py3')

## ---(Sat Dec  7 12:48:32 2019)---
runfile('C:/Users/eshah/.spyder-py3/encoding.py', wdir='C:/Users/eshah/.spyder-py3')
runfile('C:/Users/eshah/.spyder-py3/leftroatation.py', wdir='C:/Users/eshah/.spyder-py3')
runfile('C:/Users/eshah/.spyder-py3/minumu.py', wdir='C:/Users/eshah/.spyder-py3')
runfile('C:/Users/eshah/.spyder-py3/encoding.py', wdir='C:/Users/eshah/.spyder-py3')
runfile('C:/Users/eshah/.spyder-py3/pallindrome.py', wdir='C:/Users/eshah/.spyder-py3')

## ---(Sat Dec  7 16:23:21 2019)---
runfile('C:/Users/eshah/.spyder-py3/pallindrome.py', wdir='C:/Users/eshah/.spyder-py3')
runfile('C:/Users/eshah/.spyder-py3/tree.py', wdir='C:/Users/eshah/.spyder-py3')
root
root.data
root.left.data
root.left.left.data
runfile('C:/Users/eshah/.spyder-py3/pallindrome.py', wdir='C:/Users/eshah/.spyder-py3')
runfile('C:/Users/eshah/.spyder-py3/tree2.py', wdir='C:/Users/eshah/.spyder-py3')

## ---(Tue Dec 10 11:08:22 2019)---
runfile('C:/Users/eshah/.spyder-py3/findpairs.py', wdir='C:/Users/eshah/.spyder-py3')
runfile('C:/Users/eshah/.spyder-py3/tree2.py', wdir='C:/Users/eshah/.spyder-py3')

## ---(Tue Dec 10 17:53:13 2019)---
runfile('C:/Users/eshah/.spyder-py3/common.py', wdir='C:/Users/eshah/.spyder-py3')
runfile('C:/Users/eshah/.spyder-py3/common.py', wdir='C:/Users/eshah/.spyder-py3')

## ---(Wed Dec 11 13:29:04 2019)---
runfile('C:/Users/eshah/.spyder-py3/more.py', wdir='C:/Users/eshah/.spyder-py3')
runfile('C:/Users/eshah/.spyder-py3/duplicates.py', wdir='C:/Users/eshah/.spyder-py3')
runfile('C:/Users/eshah/.spyder-py3/duplicates.py', wdir='C:/Users/eshah/.spyder-py3')

## ---(Wed Dec 11 19:13:41 2019)---
runfile('C:/Users/eshah/.spyder-py3/compare.py', wdir='C:/Users/eshah/.spyder-py3')
runfile('C:/Users/eshah/.spyder-py3/matrix.py', wdir='C:/Users/eshah/.spyder-py3')
runfile('C:/Users/eshah/.spyder-py3/plusminus.py', wdir='C:/Users/eshah/.spyder-py3')

## ---(Thu Dec 12 17:10:59 2019)---
runfile('C:/Users/eshah/.spyder-py3/plusminus.py', wdir='C:/Users/eshah/.spyder-py3')

## ---(Thu Dec 12 22:28:12 2019)---
runfile('C:/Users/eshah/.spyder-py3/plusminus.py', wdir='C:/Users/eshah/.spyder-py3')