# -*- coding: utf-8 -*-
"""
Created on Wed Dec  4 19:11:21 2019

@author: eshah
"""

#!/bin/python3
"""
l=[]
s=0
a=[10 ,20, 20, 10, 10, 30, 50, 10, 20]
a=[1, 1, 3, 1, 2, 1, 3, 3, 3, 3]
for i in range(0,len(a)):
    count=1
    for j in range(i+1,len(a)):
        if(a[i]==a[j] and a[i]!=-1):
            a[j]=-1
            count=(count+1)
    s=s+count//2
print(s)
"""
"""
import re
s="UDDDUDUU"
nValleys=0
for i in range(1,len(s)):
    if(s[i]=='U' and s[i-1]=='D'):
        nValleys+=1
print(nValleys)

"""
"""
m=re.findall(p,s)
print(len(m))
print(m)
"""

prices=[1,3,5,7,1]
l=[]
l=sorted(prices)
print(l)