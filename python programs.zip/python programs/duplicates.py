# -*- coding: utf-8 -*-
"""
Created on Wed Dec 11 14:14:54 2019

@author: eshah
"""


# Complete the alternatingCharacters function below.
f=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
print(len(f))