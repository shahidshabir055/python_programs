# -*- coding: utf-8 -*-
"""
Created on Sun Mar  8 15:53:13 2020

@author: eshah
"""
def isParenthesis(c): 
	return ((c == '(') or (c == ')') or (c=='{') or (c=='}') or (c =='[') or (c==']')) 
def isValidString(str):
    cnt=0
    for i in range(0,len(str)):
        if(str[i] == '('):
            cnt += 1
        elif (str[i] == ')'):
            cnt -= 1
        """
        if (str[i] == '{'):
            cnt += 1
		elif (str[i] == '}'): 
			cnt -= 1
        if (str[i] == '['): 
			cnt += 1
		elif (str[i] == ']'): 
			cnt -= 1
        """
        if (cnt < 0): 
            return False
    return (cnt == 0) 
	
# method to remove invalid parenthesis 
def removeInvalidParenthesis(str): 
	if (len(str) == 0): 
		return
	visit = set() 
	s= [] 
	temp = 0
	level = 0
	s.append(str) 
	visit.add(str) 
	while(len(q)): 
		str = q[0] 
		s.pop() 
		if (isValidString(str)): 
			print(str) 
			level = True
		if (level): 
			continue
		for i in range(len(str)): 
			if (not isParenthesis(str[i])): 
				continue
			temp = str[0:i] + str[i + 1:] 
			if temp not in visit: 
				s.append(temp) 
				visit.add(temp)
            return visit
expression = "()())()"
print(removeInvalidParenthesis(expression))
expression = "()v)"
removeInvalidParenthesis(expression)